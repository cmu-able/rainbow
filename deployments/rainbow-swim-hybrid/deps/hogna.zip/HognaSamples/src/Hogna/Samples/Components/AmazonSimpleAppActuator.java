package Hogna.Samples.Components;

//import java.io.ObjectInputStream;
//import java.io.ObjectOutputStream;
//import java.net.InetAddress;
//import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

import Application.Configuration.ConfigurationManager;
//import Framework.CommandArgs;
import Framework.Cloud.Topology.Cluster;
import Framework.Cloud.Topology.Node;
import Framework.Cloud.Topology.Topology;
import Framework.Diagnostics.Trace;
import Framework.Diagnostics.Trace.TraceLevel;
//import HognaEngine.Commands.FilterScenariosCommandArgs;

// knows how to 
// - Add instances
// - Remove instance


public class AmazonSimpleAppActuator extends AmazonActuator
{
	// proxy_ip
	String m_proxyIp   = null;
	int    m_proxyPort = 9300;

	Map<String, String> mapScenarioPatterns = null;
	
	public AmazonSimpleAppActuator() throws Exception
	{
		super();
		
		this.mapScenarioPatterns = new HashMap<>();

		this.mapScenarioPatterns.put("pi", ConfigurationManager.GetSetting("Scenario Pattern: pi"));
		this.mapScenarioPatterns.put("insert", ConfigurationManager.GetSetting("Scenario Pattern: insert"));
		this.mapScenarioPatterns.put("update", ConfigurationManager.GetSetting("Scenario Pattern: update"));
		this.mapScenarioPatterns.put("select 0", ConfigurationManager.GetSetting("Scenario Pattern: select 0"));
	}
/*
	private void SendCommand(String hostIp, String sCommand)
	{
		try
		{
			InetAddress host = InetAddress.getByName(hostIp);
			Socket socket = new Socket(host.getHostName(), this.m_proxyPort);
	
			//
			// Send a message to the server application
			//
			ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
			oos.writeObject(sCommand);
	
			ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
			Object message = ois.readObject();
			System.out.println(message);
			
			oos.close();
			ois.close();
		}
		catch (Exception ex) { Trace.WriteException(ex); }
	}
	*/
	
	@Override
	public void BuildTopology(Topology topology)
	{
		super.BuildTopology(topology);
		
		Cluster cluster = this.m_topology.GetCluster("WebCluster");
		for (Node node : cluster.GetNodes())
		{
			if (node.GetType().equals("balancer"))
			{
				this.m_proxyIp = node.GetPublicIp();
				break;
			}
		}
		
		Trace.WriteLine(TraceLevel.INFO, "The topology is deployed on Amazon EC2 Cloud.");
		Trace.WriteLine(TraceLevel.INFO, "The sample web application can be accessed with the following address:");
		Trace.WriteLine(TraceLevel.INFO, "    http://%s/DatabaseOperations/InsertUsers?fName=John&lName=Smith", this.m_proxyIp);
		Trace.WriteLine(TraceLevel.INFO, "    http://%s/DatabaseOperations/UpdateUsers?fName=TheOther&lName=Smith", this.m_proxyIp);
		Trace.WriteLine(TraceLevel.INFO, "    http://%s/DatabaseOperations/SelectUsers?recordsCnt=20", this.m_proxyIp);
		Trace.WriteLine(TraceLevel.INFO, "    http://%s/DatabaseOperations/pi?digits=20&iterations=4000", this.m_proxyIp);
	}
	
//	@Override
//	public void FilterRequests(CommandArgs commandArgs)
//	{
//		FilterScenariosCommandArgs args = (FilterScenariosCommandArgs)commandArgs;
		
//		if (this.mapScenarioPatterns.containsKey(args.strScenarioName))
//		{
//			SendCommand(this.m_proxyIp, "ADD FILTER RULE: " + this.mapScenarioPatterns.get(args.strScenarioName));
//			
//			Trace.WriteLine(TraceLevel.DEBUG, "Scenario [%s] has been filtered.", args.strScenarioName);
//		}
//	}

//	@Override
//	public void UnfilterRequests(CommandArgs commandArgs)
//	{
//		FilterScenariosCommandArgs args = (FilterScenariosCommandArgs)commandArgs;

//		if (this.mapScenarioPatterns.containsKey(args.strScenarioName))
//		{
//			SendCommand(this.m_proxyIp, "REMOVE FILTER RULE: " + this.mapScenarioPatterns.get(args.strScenarioName));
//
//			Trace.WriteLine(TraceLevel.DEBUG, "Scenario [%s] has been unfiltered.", args.strScenarioName);
//		}
//	}
}
