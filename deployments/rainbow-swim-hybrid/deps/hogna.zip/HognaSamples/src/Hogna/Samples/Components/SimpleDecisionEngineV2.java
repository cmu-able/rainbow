package Hogna.Samples.Components;

import java.io.BufferedWriter;
import java.io.FileWriter;

import Application.Configuration.ConfigurationManager;
import Framework.SimpleDecisionEngine;
import Framework.Cloud.Topology.Topology;
import Framework.Diagnostics.Trace;
import Framework.Monitoring.Data.MetricValues;

/**
 * @author Cornel
 *
 * "SimpleDecisionEngineV2" is an engine specific to our test application ("DatabaseOperations").
 *
 * The "SimpleDecisionEngineV2" has access to more metrics than "SimpleDecisionEngine".
 * It serves as an example of how to customize the engine for an application.
 * 
 * The new metrics available are:
 *     - Arrival Rate
 *     - Throughput
 *     - Response Time
 *  for the each of 6 scenarios:
 *     - insert
 *     - update
 *     - select 0
 *     - select 1
 *     - select 2
 *     - select 3
 * In total there are 18 more metrics.
 * 
 * The new metrics are loged in a file - no other functionality is added in terms of
 * analyze and planning.
 * 
 * 
 * Context in which this engine is used:
 * 
 *   � An application that has 6 utilization scenarios is deployed in cloud. The application
 *   has sensors capable to collect "Arrival Rate", "Throughput" and "Response Time" for
 *   each scenario. The names of the scenarios are those specified above.
 *   
 *   The full name of the metric is: /WebCluster/[Balancer]/Arrival Rate <scenario names>
 *   E.g.: "/WebCluster/[Balancer]/Arrival Rate select 0" for the arrival rate on "select 0".
 * 
 *   � The "CPU Utilization" is also available for each worker instance.
 *   
 *   � There are 2 clusters, named "DatabaseCluster" and "WebCluster"
 *   
 */
public class SimpleDecisionEngineV2 extends SimpleDecisionEngine
{
	String[] scenarioNames = new String[] {	"insert", "update", "select 0", "select 1", "select 2", "select 3"};
	
	@Override
	protected void SaveMetricsToFile(MetricValues theMetrics, Topology theTopology)
	{
		// get the filename
		String strMetricsFile = ConfigurationManager.GetSetting("SimpleApp: Metrics File");
		if (strMetricsFile != null)
		{
			String strOutput = "";
	
			// the ID
			strOutput = String.format("%s    %16d", strOutput, System.currentTimeMillis());
	
			// servers count
			strOutput = String.format("%s    %16d", strOutput, theTopology.GetCluster("DatabaseCluster").GetSize());
			strOutput = String.format("%s    %16d", strOutput, theTopology.GetCluster("WebCluster").GetSize());
	
			// CPU utilization
			strOutput = String.format("%s    %16.2f", strOutput, theMetrics.GetMetricValueAverage("DatabaseCluster", "CPUUtilization") * 100); // average
			strOutput = String.format("%s    %16.2f", strOutput, theMetrics.GetMetricValueAverage("WebCluster", "CPUUtilization") * 100); // average
	
			for (int i = 0; i < scenarioNames.length; ++i)
			{
				double value = 0;
			
				value = theMetrics.GetMetricValue("WebCluster", "[Balancer]", "Arrival Rate " + scenarioNames[i]) * 1000;
				strOutput = String.format("%s    %16.4f", strOutput, value);
	
				value = theMetrics.GetMetricValue("WebCluster", "[Balancer]", "Throughput " + scenarioNames[i]) * 1000;
				strOutput = String.format("%s    %16.4f", strOutput, value);
				
				value = theMetrics.GetMetricValue("WebCluster", "[Balancer]", "Response Time " + scenarioNames[i]);
				strOutput = String.format("%s    %16.4f", strOutput, value);
			}
			

			try
			{
	    		BufferedWriter out;
				out = new BufferedWriter(new FileWriter(strMetricsFile, true));
	    		out.write(strOutput + "\n");
	    		out.close();
			}
			catch (Exception e) { Trace.WriteException(e); }

		}
	}
}
