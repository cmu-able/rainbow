package Hogna.Samples.Components;

import Framework.CommandArgs;
import Framework.Cloud.EC2.EC2Manager;
import Framework.Cloud.EC2.EC2ManagerSettings;
import Framework.Cloud.Topology.Topology;
import Framework.Diagnostics.Trace;
import Framework.Diagnostics.Trace.TraceLevel;
import Hogna.IActuator;
import Hogna.Commands.ExpandClusterCommandArgs;
import Hogna.Commands.ShrinkClusterCommandArgs;

//knows how to 
//- Add instances
//- Remove instance

public class AmazonActuator implements IActuator
{
	EC2Manager m_cloudManager = null;
	Topology m_topology = null;
	
	public AmazonActuator() throws Exception
	{
		EC2ManagerSettings settings = new EC2ManagerSettings();
		settings.AwsCredentialsFile = "./config/AwsCredentials.properties";
		settings.PrivateKeyFile     = "./config/AwsPrivate.key";
		settings.PublicKeyFile      = "./config/AwsPublic.key";
		settings.KeyPairName        = "Autonomic Key [Cornel]";

		this.m_cloudManager = new EC2Manager(settings);
	}
	


	
	@Override
	public void BuildTopology(Topology topology)
	{
		long start = System.currentTimeMillis();
		this.m_cloudManager.BuildTopology(topology);
		long end = System.currentTimeMillis();

		this.m_topology = topology;
		
		Trace.WriteLine(TraceLevel.DEBUG, "Building the topology took [%d]ms.", end - start);
	}
	

	@Override
	public void AddClusterNodes(CommandArgs commandArgs)
	{
		ExpandClusterCommandArgs args = (ExpandClusterCommandArgs) commandArgs;

		if (args.cntNodesToAdd > 0)
		{
			Trace.WriteLine(TraceLevel.DEBUG, "Adding [%d] servers in cluster [%s].", args.cntNodesToAdd, args.strCluster);
			
			this.m_cloudManager.AddWorkerNodes(m_topology, args.strCluster, args.cntNodesToAdd);
		}
	}

	@Override
	public void RemoveClusterNodes(CommandArgs commandArgs)
	{
		ShrinkClusterCommandArgs args = (ShrinkClusterCommandArgs) commandArgs;

		if (args.lstNodesToRemove.size() > 0)
		{
			Trace.WriteLine(TraceLevel.DEBUG, "Removing [%d] servers from cluster [%s].", args.lstNodesToRemove.size(), args.strCluster);

			this.m_cloudManager.RemoveWorkerNodes(m_topology, args.strCluster, args.lstNodesToRemove.size());
		}
	}

//	@Override
//	public void FilterRequests(CommandArgs commandArgs)
//	{
		// Filtering requests require custom software on the server.
		// In order to acomplish filtering, extend this class and override this function.
//		Trace.WriteLine(TraceLevel.DEBUG, "Filtering not implemented because it require custom software on the server. See 'AmazonSimpleAppActuator' for an example.");
//	}

//	@Override
//	public void UnfilterRequests(CommandArgs commandArgs)
//	{
		// Unfiltering requests require custom software on the server.
		// In order to acomplish unfiltering, extend this class and override this function.
//		Trace.WriteLine(TraceLevel.DEBUG, "Unfiltering not implemented because it require custom software on the server. See 'AmazonSimpleAppActuator' for an example.");
//	}
}
