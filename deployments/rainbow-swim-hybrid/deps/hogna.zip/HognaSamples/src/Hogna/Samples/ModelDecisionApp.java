package Hogna.Samples;

import Application.Configuration.ConfigurationManager;
import Framework.ClusterResizeRule;
import Framework.SimpleDecisionEngine;
import Hogna.HognaEngine;
import Hogna.Samples.Components.AmazonSimpleAppActuator;
import Hogna.Samples.Components.SimpleModelPlanner;
import Hogna.Samples.Components.TopologyMonitorManagerV2;

// Add/remove instances based on a model

public class ModelDecisionApp
{
	public static void main (String ... args) throws Exception
	{
		ConfigurationManager.Configure("./input.Samples/application.model.config ");

		HognaEngine theApp = new HognaEngine();

		theApp.SetModel("./input.Samples/Simple DB Operations.model.pxl");
		theApp.SetFilter("./input.Samples/Simple DB Operations.kalman.config");
		
		SimpleDecisionEngine analyzer = new SimpleDecisionEngine();
		analyzer.AddExpandRule(  new ClusterResizeRule("/WebCluster/Average/CPUUtilization", 0.80, "WebCluster", 0));
		analyzer.AddContractRule(new ClusterResizeRule("/WebCluster/Average/CPUUtilization", 0.40, "WebCluster", 0));
		theApp.SetAnalyzer(analyzer);

		theApp.SetPlanner(new SimpleModelPlanner());
		theApp.SetMonitorEngine(new TopologyMonitorManagerV2());
		theApp.SetActuator(new AmazonSimpleAppActuator());

		theApp.Run();
	}
}
