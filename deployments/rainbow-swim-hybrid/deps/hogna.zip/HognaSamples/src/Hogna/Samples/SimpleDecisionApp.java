package Hogna.Samples;
import Application.Configuration.ConfigurationManager;
import Framework.ClusterResizeRule;
import Framework.SimpleDecisionEngine;
//import Framework.Monitoring.TopologyMonitorManager;
import Hogna.HognaEngine;
import Hogna.Samples.Components.AmazonSimpleAppActuator;
import Hogna.Samples.Components.SimpleDecisionEngineV2;
import Hogna.Samples.Components.TopologyMonitorManagerV2;


// Add/removed instances based on a threshold
// no model used

public class SimpleDecisionApp
{
	public static void main(String[] args) throws Exception
	{
		ConfigurationManager.Configure("./input.Samples/application.simple.config");
		
		HognaEngine theApp = new HognaEngine();

		SimpleDecisionEngine decEngine = new SimpleDecisionEngineV2();
		decEngine.AddExpandRule(  new ClusterResizeRule("/WebCluster/Average/CPUUtilization", 0.80, "WebCluster",  1));
		decEngine.AddContractRule(new ClusterResizeRule("/WebCluster/Average/CPUUtilization", 0.40, "WebCluster", -1));
		theApp.SetAnalyzer(decEngine);

		theApp.SetPlanner(decEngine);
		//theApp.SetMonitorEngine(new TopologyMonitorManager());
		theApp.SetMonitorEngine(new TopologyMonitorManagerV2());
		theApp.SetActuator(new AmazonSimpleAppActuator());

		theApp.Run();
	}
}
