package Hogna.Samples.Components;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;

import Application.Configuration.ConfigurationManager;
import Framework.AbstractCommand;
import Framework.AnalyzerResults;
import Framework.ClusterResizeRule;
import Framework.Cloud.Topology.Cluster;
import Framework.Cloud.Topology.Node;
import Framework.Cloud.Topology.Topology;
import Framework.Diagnostics.Trace;
import Framework.Monitoring.Data.MetricValues;
import Hogna.HognaConstants;
import Hogna.IPlanner;
import Hogna.Commands.ExpandClusterCommand;
import Hogna.Commands.ExpandClusterCommandArgs;
import Hogna.Commands.ShrinkClusterCommand;
import Hogna.Commands.ShrinkClusterCommandArgs;

import opera.OperaModel;

public class SimpleModelPlanner implements IPlanner
{
	private ExpandClusterCommand CreateExpandCommand(OperaModel theModel, ClusterResizeRule theResizeRule)
	{
		// get current number of web nodes
		int cntWebSvr = theModel.GetXPathModelInt("/Model/Topology/Node[@name=\"WebHost\"]/@CPUParallelism");

		int svrToAdd = 0;
		double cpuEstimated = theModel.GetUtilizationNode("WebHost", "CPU");

		do
		{
			++svrToAdd;
			theModel.SetNodeMultiplicity("WebHost", cntWebSvr + svrToAdd);
			theModel.solve();
			cpuEstimated = theModel.GetUtilizationNode("WebHost", "CPU");
		}
		while (cpuEstimated > theResizeRule.treshold && svrToAdd < 5);

		if (svrToAdd > 0)
		{
			Trace.WriteLine("Decided to add [%d] more web servers (total [%d] servers). New estimated CPU utilization is [%5.2f].",
					svrToAdd, cntWebSvr + svrToAdd, cpuEstimated * 100);
			
			ExpandClusterCommandArgs args = new ExpandClusterCommandArgs();
			args.strCluster = theResizeRule.strCluster;
			args.cntNodesToAdd = svrToAdd;
			args.strNodesType = "worker";

			ExpandClusterCommand command = new ExpandClusterCommand();
			command.SetArgs(args);
			return command;
		}

		return null;
	}
	
	private ShrinkClusterCommand CreateShrinkCommand(OperaModel theModel, Topology theTopology, ClusterResizeRule theResizeRule)
	{
		// get current number of web nodes
		int cntWebSvr = theModel.GetXPathModelInt("/Model/Topology/Node[@name=\"WebHost\"]/@CPUParallelism");

		if (cntWebSvr > 1)
		{
			int svrToRemove = 0;
			double cpuEstimated = theModel.GetUtilizationNode("WebHost", "CPU");

			do
			{
				++svrToRemove;
				theModel.SetNodeMultiplicity("WebHost", cntWebSvr - svrToRemove);
				theModel.solve();
				cpuEstimated = theModel.GetUtilizationNode("WebHost", "CPU");
			}
			while (cpuEstimated < theResizeRule.treshold  && cntWebSvr - svrToRemove > 1);

			if (svrToRemove > 0)
			{
				Trace.WriteLine("Decided to remove [%d] web servers (total [%d] servers). New estimated CPU utilization is [%5.2f].",
						svrToRemove, cntWebSvr - svrToRemove, cpuEstimated * 100);

				ShrinkClusterCommandArgs args = new ShrinkClusterCommandArgs();
				args.strCluster = theResizeRule.strCluster;
				args.lstNodesToRemove = new ArrayList<>();
				
				// search the topology for a worker node in the specified cluster
				// remove workers only if there are more than one.
				Cluster cluster = theTopology.GetCluster(theResizeRule.strCluster);
				for (Node node : cluster.GetNodes())
				{
					if (node.GetType().equals("worker"))
					{
						args.lstNodesToRemove.add(node.GetId());
						if (args.lstNodesToRemove.size() == svrToRemove)
						{
							break;
						}
					}
				}

				ShrinkClusterCommand command = new ShrinkClusterCommand();
				command.SetArgs(args);
				return command;
			}
		}
		
		return null;
	}
	


	@Override
	public ArrayList<AbstractCommand> CreateActionPlan(MetricValues theMetrics,
			AnalyzerResults analyzerResults, Topology topology,
			OperaModel theModel)
	{
		this.SaveMetricsToFile(theMetrics, topology);
		
		ArrayList<AbstractCommand> actionPlan = new ArrayList<>();
		
		switch(analyzerResults.resultCode)
		{
			case HognaConstants.SYSTEM_OVERLOAD:
			{
				AbstractCommand command = this.CreateExpandCommand(theModel, (ClusterResizeRule)analyzerResults.data);
				if (command != null)
				{
					actionPlan.add(command);
				}
				break;
			}
			case HognaConstants.SYSTEM_UNDERLOAD:
			{
				AbstractCommand command = this.CreateShrinkCommand(theModel, topology, (ClusterResizeRule)analyzerResults.data);
				if (command != null)
				{
					actionPlan.add(command);
				}
				break;
			}
			case HognaConstants.SYSTEM_HEALTHY:
				break;
			default:
				break;
		}

		return actionPlan;
	}

	
	String[] scenarioNames = new String[] {	"insert", "update", "select 0", "select 1", "select 2", "select 3"};
	
	protected void SaveMetricsToFile(MetricValues theMetrics, Topology theTopology)
	{
		// get the filename
		String strMetricsFile = ConfigurationManager.GetSetting("ModelApp: Metrics File");
		if (strMetricsFile != null)
		{
			String strOutput = "";
	
			// the ID
			strOutput = String.format("%s    %16d", strOutput, System.currentTimeMillis());
	
			// servers count
			strOutput = String.format("%s    %16d", strOutput, theTopology.GetCluster("DatabaseCluster").GetSize());
			strOutput = String.format("%s    %16d", strOutput, theTopology.GetCluster("WebCluster").GetSize());
	
			// CPU utilization
			strOutput = String.format("%s    %16.2f", strOutput, theMetrics.GetMetricValueAverage("DatabaseCluster", "CPUUtilization") * 100); // average
			strOutput = String.format("%s    %16.2f", strOutput, theMetrics.GetMetricValueAverage("WebCluster", "CPUUtilization") * 100); // average
	
			for (int i = 0; i < scenarioNames.length; ++i)
			{
				double value = 0;
			
				value = theMetrics.GetMetricValue("WebCluster", "[Balancer]", "Arrival Rate " + scenarioNames[i]) * 1000;
				strOutput = String.format("%s    %16.4f", strOutput, value);
	
				value = theMetrics.GetMetricValue("WebCluster", "[Balancer]", "Throughput " + scenarioNames[i]) * 1000;
				strOutput = String.format("%s    %16.4f", strOutput, value);
				
				value = theMetrics.GetMetricValue("WebCluster", "[Balancer]", "Response Time " + scenarioNames[i]);
				strOutput = String.format("%s    %16.4f", strOutput, value);
			}
			

			try
			{
	    		BufferedWriter out;
				out = new BufferedWriter(new FileWriter(strMetricsFile, true));
	    		out.write(strOutput + "\n");
	    		out.close();
			}
			catch (Exception e) { Trace.WriteException(e); }

		}
	}
}
