package Hogna.Samples.Components;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;

import Framework.Cloud.Topology.Cluster;
import Framework.Cloud.Topology.Node;
import Framework.Cloud.Topology.Topology;
import Framework.Monitoring.TopologyMonitorManager;
import Framework.Monitoring.Data.MetricValues;
import ProxyServer.Monitoring.DataSample;

public class TopologyMonitorManagerV2 extends TopologyMonitorManager
{
	private String m_proxyIp = null;
	
	@Override
	public void UpdateMonitorList(Topology theTopology)
	{
		super.UpdateMonitorList(theTopology);
		
		if (this.m_proxyIp == null)
		{
			Cluster cluster = theTopology.GetCluster("WebCluster");
			for (Node node : cluster.GetNodes())
			{
				if (node.GetType().equals("balancer"))
				{
					this.m_proxyIp = node.GetPublicIp();
					break;
				}
			}
		}
	}

	@Override
	public MetricValues GetLastSample()
	{
		MetricValues theMetrics = super.GetLastSample();
		if (theMetrics == null)
		{
			theMetrics = new MetricValues();
		}
		
		try
		{
			InetAddress host = InetAddress.getByName(this.m_proxyIp);
			Socket socket = new Socket(host.getHostName(), 9300);
		 
			// get 120 samples, each representing data for 1 second.
			// ignore the first 60 samples (latest minute data), because CloudWatch does not
			// provide reliable data for the last minute. Do this to keep this data in sync
			// with the data provided by amazon.
			ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
			oos.writeObject("GET DATA WINDOW: 120");
		 
			ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
			DataSample[] samples = (DataSample[]) ois.readObject();
	
			if (samples.length > 0)
			{
				int cntScenarios = samples[0].scenarioNames.length;
				double[] throughput   = new double[cntScenarios];
				double[] arrivalRateU = new double[cntScenarios];
				double[] arrivalRateB = new double[cntScenarios];
				double[] responseTime = new double[cntScenarios];
				double timeTotal = 0;
				for (int j = 60; j < samples.length; ++j)//for (DataSample sample : samples)
				{
					DataSample sample = samples[j];
	
					timeTotal += sample.sampleIntervalLength;
					for (int i = 0; i < cntScenarios; ++i)
					{
						throughput[i]   += sample.requestsProcessedCnt[i];
						arrivalRateU[i] += sample.requestsCnt[i];
						arrivalRateB[i] += sample.requestsBlockedCnt[i];
						responseTime[i] += sample.responseTime[i] * sample.requestsProcessedCnt[i];
					}
				}
				double timeInSeconds = timeTotal / 1000.0;
				for (int i = 0; i < cntScenarios; ++i)
				{
					theMetrics.AddMetricValue("WebCluster", "[Balancer]",
							"Throughput " + samples[0].scenarioNames[i],
							throughput[i] / timeInSeconds / 1000);
	
					theMetrics.AddMetricValue("WebCluster", "[Balancer]",
							"Arrival Rate " + samples[0].scenarioNames[i],
							(arrivalRateU[i] + arrivalRateB[i]) / timeInSeconds / 1000);
	
					theMetrics.AddMetricValue("WebCluster", "[Balancer]",
							"Response Time " + samples[0].scenarioNames[i],
							throughput[i] == 0 ? 0 : responseTime[i] / throughput[i]);
					
					theMetrics.AddMetricValue("WebCluster", "[Balancer]",
							"Users " + samples[0].scenarioNames[i],
							throughput[i] == 0 ? 0 : throughput[i] / timeTotal * (responseTime[i] / throughput[i] + 3000));
					// throughput[0] / timeTotal * (responseTime[0] / throughput[0] + 3000)
				}
			}
		}
		catch(Exception ex) {}

		return theMetrics;
	}
}
