package Hogna.Samples.Components;

import java.util.ArrayList;

import Application.Configuration.ConfigurationManager;
import Application.Configuration.MonitorConfigurationSection;
import Framework.Cloud.Topology.Cluster;
import Framework.Cloud.Topology.Node;
import Framework.Cloud.Topology.Topology;
import Framework.Monitoring.Monitor;
import Framework.Monitoring.MonitorManager;

public class SimpleAppMonitorEngine extends MonitorManager
{
	Monitor[] m_lstMonitorTemplates = null;
	
	public SimpleAppMonitorEngine()
	{
		this.m_lstMonitorTemplates = ((MonitorConfigurationSection)ConfigurationManager.GetSection("monitoring")).GetMonitors();
	}
	
	public void UpdateMonitorList(Topology theTopology)
	{
		ArrayList<Monitor> lstMonitors = new ArrayList<Monitor>();

		for (Monitor monitorTpl : this.m_lstMonitorTemplates)
		{
			for (Cluster cluster : theTopology.GetClusters())
			{
				for (Node node : cluster.GetNodes())
				{
					if (node.GetType().equals("worker"))
					{
						Monitor newMonitor = monitorTpl.Clone();
						newMonitor.SetTarget(node);
						
						lstMonitors.add(newMonitor);
					}
				}
			}
		}
		
		this.SetMonitors(lstMonitors.toArray(new Monitor[lstMonitors.size()]));
	}
}
